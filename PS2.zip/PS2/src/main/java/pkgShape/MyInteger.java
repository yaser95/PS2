package pkgShape;

public class MyInteger {
private int iValue;
	
	public MyInteger(int value){
		iValue = value;
	}
	
	public int getValue(){
		return iValue;
	}
	
	public boolean isEven(){
		return isEven(iValue);
	}
	
	public boolean isOdd(){
		return isOdd(iValue);
	}
	
	public boolean isPrime(){
		return isPrime(iValue);
	}

	public static boolean isEven(int value){
		return value%2==0;
	}
	
	public static boolean isOdd(int value){
		return (value%2!=0);
	}
	
	public static boolean isPrime(int value)
	{
		for(int i=1; i<value; i++){
			if(value%i==0)
				return false;
		}
		return true;
	}
	
	public static boolean isEven(MyInteger mint){
		return isEven(mint.getValue());
	}
	
	public static boolean isOdd(MyInteger mint){
		return isOdd(mint.getValue());
	}
	
	public static boolean isPrime(MyInteger mint){
		return isPrime(mint.getValue());
	}
	
	public boolean equals(int value){
		return iValue==value;
	}
	
	public boolean equals(MyInteger mint){
		return equals(mint.getValue());
	}
		
	public static void main(String[] args){

		MyInteger classinstance=new MyInteger(7);
		System.out.println(classinstance.isEven());
		System.out.println(isEven(5));
		System.out.println(classinstance.getValue());
		System.out.println(classinstance.isPrime());
		System.out.println(classinstance.equals(8));

	}

}
